﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class PlayerMovement : MonoBehaviour {

	public float speed;
	private Vector3 dir;
	private bool isDead;
	public GameObject resetButton;
	private int score = 0;
	public Text Scoretext;
	// Use this for initialization
	void Start () {
		isDead = false;
		dir = Vector3.zero;
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetMouseButtonDown (0) && !isDead) {
			score+=2;
			Scoretext.text = score.ToString ();
			if (dir == Vector3.forward)
				dir = Vector3.left;
			else
				dir = Vector3.forward;
		}

		float amountToMove = speed * Time.deltaTime;
		transform.Translate (dir * amountToMove);
	}

	public Transform mainCamera;
	void OnTriggerExit(Collider other)
	{
		
		Debug.Log("OnTriggerExit1");
		if (other.tag == "Tile") 
		{
			Debug.Log("OnTriggerExit2");
			RaycastHit hit;
			Ray downRay = new Ray (transform.position, -Vector3.up);
			if(!Physics.Raycast(downRay, out hit))
			{
				Debug.Log("OnTriggerExit3");
				isDead = true;
				resetButton.SetActive (true);
				if(transform.childCount>0)
					transform.GetChild(0).transform.parent = null;
			}
		}
	}

//	void OnCollisionExit(Collision ob)
//	{
//		if (ob.collider.tag == "FirstTile") 
//		{
//			isDead = true;
//			mainCamera.parent = null;
//		}
//	}

}
